RAJA TURBO RUSH — मोबाइल से APK बनाने का तरीका

यह Android Studio source project है। इसमें GitHub Actions workflow जोड़ा गया है ताकि कंप्यूटर के बिना GitHub के cloud runner पर debug APK बनाया जा सके।

मोबाइल से:
1. GitHub.com पर अकाउंट बनाएँ/लॉगिन करें।
2. New repository बनाएँ और नाम RajaTurboRush रखें। Public चुनें।
3. इस ZIP को फोन में Extract करें।
4. GitHub repository में Add file > Upload files चुनकर ZIP के अंदर की सभी फाइलें/फोल्डर अपलोड करें। .github फोल्डर भी अपलोड होना चाहिए।
5. Commit changes दबाएँ।
6. Repository में Actions टैब खोलें। "Build Raja Turbo Rush APK" workflow चलने दें।
7. Build सफल होने पर Actions > सबसे नया run > Artifacts में Raja-Turbo-Rush-debug-APK डाउनलोड करें।
8. ZIP artifact Extract करें। app-debug.apk पर टैप करके इंस्टॉल करें। Android चेतावनी दिखा सकता है; APK केवल अपने प्रोजेक्ट से आया हो तभी आगे बढ़ें।

महत्वपूर्ण:
- यह debug/test APK होगा, Play Store release APK/AAB नहीं।
- Play Store के लिए release signing, app privacy disclosures, testing और Play Console की शर्तें अलग से पूरी करनी होंगी।
- अभी गेम single-device demo है। ऑनलाइन अकाउंट/मल्टी-प्लेयर/backend और असली UPI भुगतान नहीं हैं।
- 1,000 कॉइन = ₹10 केवल demo गणना है, असली भुगतान का वादा नहीं।
